router = APIRouter()
logger = logging.getLogger("payloadbridge")

@router.get("/healthcheck")
async def healthcheck():
    return {"status": "ok"}
@router.get("/healthcheck")
async def healthcheck():
    return {"status": "ok"}
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from app.models.order_line import OrderPayload
from app.services.auth_utils import get_okta_headers
from app.core.config import settings
import httpx
import logging
import uuid

router = APIRouter()
logger = logging.getLogger("payloadbridge")

@router.post("/invoke_order_creation")
async def invoke_order_creation(request: Request):
    request_id = str(uuid.uuid4())
    try:
        body = await request.json()
        headers = request.headers
        access_token = headers.get("access_token")
        host_name = headers.get("hostName")
        if not access_token or not host_name:
            logger.error(f"[{request_id}] Missing access_token or hostName header")
            return JSONResponse(status_code=400, content={"error": "Missing access_token or hostName header", "request_id": request_id})

        # Validate payload
        try:
            order = OrderPayload(**body)
        except Exception as e:
            logger.error(f"[{request_id}] Validation error: {e}")
            return JSONResponse(status_code=422, content={"error": "Invalid input", "details": str(e), "request_id": request_id})

        # Get Okta/RecVue headers
        try:
            okta_headers = await get_okta_headers(access_token, host_name)
        except HTTPException as e:
            logger.error(f"[{request_id}] Auth error: {e.detail}")
            return JSONResponse(status_code=e.status_code, content={"error": "Auth error", "details": e.detail, "request_id": request_id})
        except Exception as e:
            logger.error(f"[{request_id}] Auth error: {e}")
            return JSONResponse(status_code=500, content={"error": "Auth error", "details": str(e), "request_id": request_id})

        # Forward payload to RecVue
        tenant = okta_headers["tenantIdentifier"]
        recvue_url = f"https://{tenant}.recvue.com/api/v2.0/order/orderlines"
        max_retries = 2
        for attempt in range(max_retries + 1):
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(recvue_url, json=body, headers=okta_headers, timeout=settings.TIMEOUT)
                    logger.info(f"[{request_id}] RecVue response: {resp.status_code}")
                    try:
                        content = resp.json()
                    except Exception:
                        content = {"error": "RecVue returned non-JSON response", "raw": resp.text}
                    return JSONResponse(status_code=resp.status_code, content={"recvue": content, "request_id": request_id})
            except (httpx.RequestError, httpx.HTTPStatusError) as e:
                logger.warning(f"[{request_id}] RecVue API attempt {attempt+1} failed: {e}")
                if attempt == max_retries:
                    if isinstance(e, httpx.HTTPStatusError):
                        return JSONResponse(status_code=e.response.status_code, content={"error": "RecVue error", "details": str(e), "request_id": request_id})
                    else:
                        return JSONResponse(status_code=502, content={"error": "RecVue unreachable", "details": str(e), "request_id": request_id})
            except Exception as e:
                logger.error(f"[{request_id}] Downstream error: {e}")
                if attempt == max_retries:
                    return JSONResponse(status_code=500, content={"error": "Failed to reach RecVue API", "details": str(e), "request_id": request_id})
    except Exception as e:
        logger.critical(f"[{request_id}] Unhandled error: {e}")
        return JSONResponse(status_code=500, content={"error": "Internal server error", "details": str(e), "request_id": request_id})