# Configuration constants for PayloadBridge

REC_VUE_BASE_URL = "https://<tenant>.recvue.com/api/v2.0/order/orderlines"
# Add more config as needed (timeouts, etc)
